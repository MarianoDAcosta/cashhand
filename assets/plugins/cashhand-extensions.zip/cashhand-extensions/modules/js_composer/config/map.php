<?php
/**
 * WPBakery Visual Composer Shortcodes settings
 *
 * @package cashhand
 *
 */

if ( function_exists( 'vc_map' ) ) :

	$nav_menus = wp_get_nav_menus();

	$nav_menus_option = array(
		esc_html__( 'Select a menu', 'cashhand-extensions' )		=> '',
	);
	
	foreach ( $nav_menus as $key => $nav_menu ) {
		$nav_menus_option[$nav_menu->name] = $nav_menu->term_id;
	}

	$revsliders = array(
		esc_html__( 'No sliders found', 'cashhand-extensions' )		=> '',
	);
	
	if ( class_exists( 'RevSlider' ) ) {
		$slider = new RevSlider();
		$arrSliders = $slider->getArrSliders();

		if ( $arrSliders ) {
			foreach ( $arrSliders as $slider ) {
				$revsliders[ $slider->getTitle() ] = $slider->getAlias();
			}
		}
	}

	$banners_1_6_params = array();

	for( $i = 0; $i < 7; $i++ ) {
		$index = $i + 1;
		$banners_1_6_params[] = array(
			'type' 			=> 'attach_image',
			'heading' 		=> esc_html__( 'Image', 'cashhand-extensions' ) . ' ' . $index,
			'param_name' 	=> "image_${i}",
		);

		$banners_1_6_params[] = array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__('Action Link', 'cashhand-extensions' ) . ' ' . $index,
			'param_name'	=> "action_link_${i}",
		);
		$banners_1_6_params[] = array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__('Extra Class for Banner', 'cashhand-extensions' ) . ' ' . $index,
			'param_name'	=> "el_class_${i}",
		);
	}

	$banners_1_6_params[] = array(
		'type' 			=> 'textfield',
		'class' 		=> '',
		'heading' 		=> esc_html__( 'Extra Class', 'cashhand-extensions' ),
		'param_name' 	=> 'el_class',
		'description' 	=> esc_html__( 'Add your extra classes here.', 'cashhand-extensions' )
	);

	#-----------------------------------------------------------------
	# Cashhand Ad Element
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Ad Block', 'cashhand-extensions' ),
			'base'  		=> 'cashhand_ad_block',
			'description'	=> esc_html__( 'Add Ad Block to your page.', 'cashhand-extensions' ),
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'icon' 			=> 'vc-el-element-icon',
			'params' 		=> array(
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Image', 'cashhand-extensions' ),
					'param_name' 	=> 'image',
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Caption Text', 'cashhand-extensions' ),
					'param_name'	=> 'caption_text',
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Action Text', 'cashhand-extensions' ),
					'param_name'	=> 'action_text',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Action Link', 'cashhand-extensions' ),
					'param_name'	=> 'action_link',
				),
			),
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Slider with Ads Element
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'				=> esc_html__( 'Slider with Ads Block', 'cashhand-extensions' ),
			'base'				=> 'cashhand_slider_with_ads_block',
			'description'		=> esc_html__( 'Add Slider with Ads Block to your page.', 'cashhand-extensions' ),
			'category'			=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'icon'				=> 'vc-el-element-icon',
			'params' 			=> array(
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Slider', 'cashhand-extensions' ),
					'param_name'	=> 'rev_slider_alias',
					'value'			=> $revsliders,
				),
				array(
					'type' 		 => 'param_group',
					'value' 	 => '',
					'heading'	 => esc_html__('Ads', 'cashhand-extensions' ),
					'param_name' => 'ads_banners',
					'params' 	 => array(
						array(
							'type' 			=> 'attach_image',
							'heading' 		=> esc_html__( 'Image', 'cashhand-extensions' ),
							'param_name' 	=> 'ad_image',
						),
						array(
							'type'			=> 'textarea',
							'heading'		=> esc_html__('Caption Text', 'cashhand-extensions' ),
							'param_name'	=> 'ad_text',
						),
						array(
							'type'			=> 'textarea',
							'heading'		=> esc_html__('Action Text', 'cashhand-extensions' ),
							'param_name'	=> 'action_text',
						),
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Action Link', 'cashhand-extensions' ),
							'param_name'	=> 'action_link',
						),
					)
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div'
				)
			),
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products carousel Banner Vertical Tabs
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Products carousel Banner Vertical Tabs', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_carousel_banner_vertical_tabs',
			'description' => esc_html__( 'Add Products carousel with Banner Vertical Tabs to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(

				array(
					'type' 		 => 'param_group',
					'value' 	 => '',
					'heading'	 => esc_html__('Tabs', 'cashhand-extensions' ),
					'param_name' => 'tabs',
					'params' 	 => array(
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Tab Title', 'cashhand-extensions' ),
							'param_name'	=> 'title',
							'description'	=> esc_html__('Enter tab title.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textarea',
							'heading'		=> esc_html__('Tab Title', 'cashhand-extensions' ),
							'param_name'	=> 'tab_title',
							'description'	=> esc_html__('Enter your banner title here.', 'cashhand-extensions'),
						),

						array(
							'type'			=> 'textarea',
							'heading'		=> esc_html__('Tab Sub Title', 'cashhand-extensions' ),
							'param_name'	=> 'tab_sub_title',
							'description'	=> esc_html__('Enter your banner subtitle here.', 'cashhand-extensions'),
						),

						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Banner Action Text', 'cashhand-extensions' ),
							'param_name'	=> 'action_text',
							'description'	=> esc_html__('Enter your banner action text here.', 'cashhand-extensions'),
						),

						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Banner Action Link', 'cashhand-extensions' ),
							'param_name'	=> 'action_link',
							'description'	=> esc_html__('Enter your banner action link here.', 'cashhand-extensions'),
						),

						array(
							'type' 			=> 'attach_image',
							'heading' 		=> esc_html__( 'Banner Image', 'cashhand-extensions' ),
							'param_name' 	=> 'banner_image',
						),
					)
				),

				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Background Image', 'cashhand-extensions' ),
					'param_name' 	=> 'bg_img',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of products to display', 'cashhand-extensions' ),
					'param_name' => 'limit',
					'value' => '20',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items', 'cashhand-extensions' ),
					'param_name' => 'items',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(0 - 479)', 'cashhand-extensions' ),
					'param_name' => 'items_0',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(480 - 767)', 'cashhand-extensions' ),
					'param_name' => 'items_480',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(768 - 991)', 'cashhand-extensions' ),
					'param_name' => 'items_768',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(992 - 1199)', 'cashhand-extensions' ),
					'param_name' => 'items_992',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(992 - 1199)', 'cashhand-extensions' ),
					'param_name' => 'items_1200',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_nav',
					'heading' => esc_html__( 'Carousel: Show Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				)
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Ads with Banner Element
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'				=> esc_html__( 'Ads with Banners Block', 'cashhand-extensions' ),
			'base'				=> 'cashhand_ads_with_banners_block',
			'description'		=> esc_html__( 'Add Ads with Banner Block to your page.', 'cashhand-extensions' ),
			'category'			=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'icon'				=> 'vc-el-element-icon',
			'params' 		=> array(
				array(
					'type' 		 => 'param_group',
					'value' 	 => '',
					'heading'	 => esc_html__('Ads with Banner', 'cashhand-extensions' ),
					'param_name' => 'ads_banners',
					'params' 	 => array(
						array(
							'type'			=> 'textarea',
							'heading'		=> esc_html__('Title', 'cashhand-extensions' ),
							'param_name'	=> 'title',
						),
						array(
							'type'			=> 'textarea',
							'heading'		=> esc_html__('Description', 'cashhand-extensions' ),
							'param_name'	=> 'description',
						),
						array(
							'type'			=> 'textarea',
							'heading'		=> esc_html__('Price', 'cashhand-extensions' ),
							'param_name'	=> 'price',
						),
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Action Link', 'cashhand-extensions' ),
							'param_name'	=> 'action_link',
						),
						array(
							'type' 			=> 'attach_image',
							'heading' 		=> esc_html__( 'Image', 'cashhand-extensions' ),
							'param_name' 	=> 'image',
						),
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Banner Action Link', 'cashhand-extensions' ),
							'param_name'	=> 'banner_action_link',
						),
						array(
							'type' 			=> 'attach_image',
							'heading' 		=> esc_html__( 'Banner Image', 'cashhand-extensions' ),
							'param_name' 	=> 'banner_image',
						),
						array(
							'type' 			=> 'checkbox',
							'param_name' 	=> 'is_align_end',
							'heading' 		=> esc_html__( 'Banner Alignment', 'cashhand-extensions' ),
							'value' 		=> array( esc_html__( 'Is End', 'cashhand-extensions' ) => 'true'
							)
						),
					)
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div'
				)
			),
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Feature Element
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Feature Block', 'cashhand-extensions' ),
			'base'  		=> 'cashhand_feature_block',
			'description'	=> esc_html__( 'Add Feature Block to your page.', 'cashhand-extensions' ),
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'icon' 			=> 'vc-el-element-icon',
			'params' 		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Icon 1', 'cashhand-extensions' ),
					'param_name'	=> 'icon_1',
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Text 1', 'cashhand-extensions' ),
					'param_name'	=> 'text_1',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Icon 2', 'cashhand-extensions' ),
					'param_name'	=> 'icon_2',
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Text 2', 'cashhand-extensions' ),
					'param_name'	=> 'text_2',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Icon 3', 'cashhand-extensions' ),
					'param_name'	=> 'icon_3',
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Text 3', 'cashhand-extensions' ),
					'param_name'	=> 'text_3',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Icon 4', 'cashhand-extensions' ),
					'param_name'	=> 'icon_4',
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Text 4', 'cashhand-extensions' ),
					'param_name'	=> 'text_4',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Icon 5', 'cashhand-extensions' ),
					'param_name'	=> 'icon_5',
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Text 5', 'cashhand-extensions' ),
					'param_name'	=> 'text_5',
				),
			),
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Jumbotron Element
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Jumbotron', 'cashhand-extensions' ),
			'base'  		=> 'cashhand_jumbotron',
			'description'	=> esc_html__( 'Add Jumbotron to your page.', 'cashhand-extensions' ),
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'icon' 			=> 'vc-el-element-icon',
			'params' 		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Title', 'cashhand-extensions' ),
					'param_name'	=> 'title',
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Sub Title', 'cashhand-extensions' ),
					'param_name'	=> 'sub_title',
				),
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Image', 'cashhand-extensions' ),
					'param_name' 	=> 'image',
				),
			),
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product Tabs Element
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Product Tabs', 'cashhand-extensions' ),
			'base'  		=> 'cashhand_product_tabs',
			'description'	=> esc_html__( 'Add Product Tabs to your page.', 'cashhand-extensions' ),
			'category'		=> esc_html__( 'Cashhand Deprecated Elements', 'cashhand-extensions' ),
			'icon' 			=> 'vc-el-element-icon',
			'params' 		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Tab #1 title', 'cashhand-extensions' ),
					'param_name'	=> 'tab_title_1',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Tab #1 Content, Show :', 'cashhand-extensions' ),
					'param_name'	=> 'tab_content_1',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Product IDs', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Products Shortcode', 'cashhand-extensions' ),
					'param_name' => 'product_id_1',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Category Slug', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Product Category Shortcode', 'cashhand-extensions' ),
					'param_name' => 'category_1',
					'holder' => 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Tab #2 title', 'cashhand-extensions' ),
					'param_name'	=> 'tab_title_2',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Tab #2 Content, Show :', 'cashhand-extensions' ),
					'param_name'	=> 'tab_content_2',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' ) 				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Product IDs', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Products Shortcode', 'cashhand-extensions' ),
					'param_name' => 'product_id_2',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Category Slug', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Product Category Shortcode', 'cashhand-extensions' ),
					'param_name' => 'category_2',
					'holder' => 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Tab #3 title', 'cashhand-extensions' ),
					'param_name'	=> 'tab_title_3',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Tab #3 Content, Show :', 'cashhand-extensions' ),
					'param_name'	=> 'tab_content_3',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' ) 				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Product IDs', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Products Shortcode', 'cashhand-extensions' ),
					'param_name' => 'product_id_3',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Category Slug', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Product Category Shortcode', 'cashhand-extensions' ),
					'param_name' => 'category_3',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Product Items', 'cashhand-extensions' ),
					'param_name' => 'product_items',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Product Columns', 'cashhand-extensions' ),
					'param_name' => 'product_columns',
					'holder' => 'div'
				),
			),
		)
	);

	vc_map(
		array(
			'name'				=> esc_html__( 'Product Tabs', 'cashhand-extensions' ),
			'base'  			=> 'cashhand_products_tabs',
			'description'		=> esc_html__( 'Add Product Tabs to your page.', 'cashhand-extensions' ),
			'category'			=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'icon' 				=> 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'params' 			=> array(
				array(
					'type' 		 => 'param_group',
					'value' 	 => '',
					'heading'	 => esc_html__('Tabs', 'cashhand-extensions' ),
					'param_name' => 'tabs',
					'params' 	 => array(
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Title', 'cashhand-extensions' ),
							'param_name'	=> 'title',
							'description'	=> esc_html__('Enter title.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'dropdown',
							'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
							'param_name'	=> 'shortcode_tag',
							'value'			=> array(
								esc_html__( 'Select', 'cashhand-extensions' )				=> '',
								esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
								esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
								esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
								esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
								esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
								esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
								esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
								esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
							),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
							'param_name'	=> 'per_page',
							'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
						),

						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Columns', 'cashhand-extensions' ),
							'param_name'	=> 'columns',
							'description'	=> esc_html__('Enter the number of columns to display.', 'cashhand-extensions'),
						),

						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Columns Wide', 'cashhand-extensions' ),
							'param_name'	=> 'columns_wide',
							'description'	=> esc_html__('Enter the number of columns wide to display.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Order By', 'cashhand-extensions' ),
							'param_name'	=> 'orderby',
							'description'	=> esc_html__('Enter orderby.', 'cashhand-extensions'),
							'value'			=> 'date'
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Order', 'cashhand-extensions' ),
							'param_name'	=> 'order',
							'description'	=> esc_html__('Enter order.', 'cashhand-extensions'),
							'value'			=> 'desc'
						),
						
						array(
							'type'			=> 'dropdown',
							'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
							'param_name'	=> 'products_choice',
							'value'			=> array(
								esc_html__( 'Select', 'cashhand-extensions' )		=> '',
								esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
								esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
							),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
							'param_name'	=> 'product_id',
							'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
							'param_name'	=> 'category',
							'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
							'param_name'	=> 'cat_operator',
							'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
							'value'			=> 'IN',
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
							'param_name'	=> 'attribute',
							'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
							'param_name'	=> 'terms',
							'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
							'param_name'	=> 'terms_operator',
							'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
							'value'			=> 'IN',
						),
					)
				),
			),
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product Carousel Tabs Element
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Product Carousel Tabs', 'cashhand-extensions' ),
			'base'  		=> 'cashhand_products_carousel_tabs',
			'description'	=> esc_html__( 'Add Product Carousel Tabs to your page.', 'cashhand-extensions' ),
			'category'		=> esc_html__( 'Cashhand Deprecated Elements', 'cashhand-extensions' ),
			'icon'			=> 'vc-el-element-icon',
			'params' 		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Tab #1 title', 'cashhand-extensions' ),
					'param_name'	=> 'tab_title_1',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Tab #1 Content, Show :', 'cashhand-extensions' ),
					'param_name'	=> 'tab_content_1',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Product IDs', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Products Shortcode', 'cashhand-extensions' ),
					'param_name' => 'product_id_1',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Category Slug', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Product Category Shortcode', 'cashhand-extensions' ),
					'param_name' => 'category_1',
					'holder' => 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Tab #2 title', 'cashhand-extensions' ),
					'param_name'	=> 'tab_title_2',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Tab #2 Content, Show :', 'cashhand-extensions' ),
					'param_name'	=> 'tab_content_2',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' ) 				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Product IDs', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Products Shortcode', 'cashhand-extensions' ),
					'param_name' => 'product_id_2',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Category Slug', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Product Category Shortcode', 'cashhand-extensions' ),
					'param_name' => 'category_2',
					'holder' => 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Tab #3 title', 'cashhand-extensions' ),
					'param_name'	=> 'tab_title_3',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Tab #3 Content, Show :', 'cashhand-extensions' ),
					'param_name'	=> 'tab_content_3',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' ) 				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Product IDs', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Products Shortcode', 'cashhand-extensions' ),
					'param_name' => 'product_id_3',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Category Slug', 'cashhand-extensions' ),
					'description' => esc_html__( 'This will only for Product Category Shortcode', 'cashhand-extensions' ),
					'param_name' => 'category_3',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Product Items', 'cashhand-extensions' ),
					'param_name' => 'product_items',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Product Columns', 'cashhand-extensions' ),
					'param_name' => 'product_columns',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Header Align', 'cashhand-extensions' ),
					'param_name'	=> 'nav_align',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' ) 	=> '',
						esc_html__( 'Center', 'cashhand-extensions' )	=> 'center',
						esc_html__( 'Left', 'cashhand-extensions' )		=> 'left',
						esc_html__( 'Right', 'cashhand-extensions' )		=> 'right',
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(0 - 479)', 'cashhand-extensions' ),
					'param_name' => 'items_0',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(480 - 767)', 'cashhand-extensions' ),
					'param_name' => 'items_480',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(768 - 991)', 'cashhand-extensions' ),
					'param_name' => 'items_768',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(992 - 1199)', 'cashhand-extensions' ),
					'param_name' => 'items_992',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(1200 - 1440)', 'cashhand-extensions' ),
					'param_name' => 'items_1200',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
			),
		)
	);

	vc_map(
		array(
			'name'				=> esc_html__( 'Product Carousel Tabs', 'cashhand-extensions' ),
			'base'  			=> 'cashhand_products_tabs_carousel',
			'description'		=> esc_html__( 'Add Product Carousel Tabs to your page.', 'cashhand-extensions' ),
			'category'			=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'icon'				=> 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'params' 			=> array(
				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Header Align', 'cashhand-extensions' ),
					'param_name'	=> 'nav_align',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' ) 	=> '',
						esc_html__( 'Center', 'cashhand-extensions' )	=> 'center',
						esc_html__( 'Left', 'cashhand-extensions' )		=> 'left',
						esc_html__( 'Right', 'cashhand-extensions' )		=> 'right',
					),
				),
				
				array(
					'type' 		 => 'param_group',
					'value' 	 => '',
					'heading'	 => esc_html__('Tabs', 'cashhand-extensions' ),
					'param_name' => 'tabs',
					'params' 	 => array(
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Title', 'cashhand-extensions' ),
							'param_name'	=> 'title',
							'description'	=> esc_html__('Enter title.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'dropdown',
							'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
							'param_name'	=> 'shortcode_tag',
							'value'			=> array(
								esc_html__( 'Select', 'cashhand-extensions' )				=> '',
								esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
								esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
								esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
								esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
								esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
								esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
								esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
								esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
							),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
							'param_name'	=> 'per_page',
							'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Order By', 'cashhand-extensions' ),
							'param_name'	=> 'orderby',
							'description'	=> esc_html__('Enter orderby.', 'cashhand-extensions'),
							'value'			=> 'date'
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Order', 'cashhand-extensions' ),
							'param_name'	=> 'order',
							'description'	=> esc_html__('Enter order.', 'cashhand-extensions'),
							'value'			=> 'desc'
						),
						
						array(
							'type'			=> 'dropdown',
							'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
							'param_name'	=> 'products_choice',
							'value'			=> array(
								esc_html__( 'Select', 'cashhand-extensions' )		=> '',
								esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
								esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
							),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
							'param_name'	=> 'product_id',
							'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
							'param_name'	=> 'category',
							'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
							'param_name'	=> 'cat_operator',
							'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
							'value'			=> 'IN',
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
							'param_name'	=> 'attribute',
							'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
							'param_name'	=> 'terms',
							'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
							'param_name'	=> 'terms_operator',
							'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
							'value'			=> 'IN',
						),
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items', 'cashhand-extensions' ),
					'param_name' => 'items',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
			),
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products Cards Carousel
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Products Cards Carousel', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_cards_carousel',
			'description' => esc_html__( 'Add products cards carousel to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'	  => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Rows', 'cashhand-extensions' ),
					'param_name' => 'rows',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Columns', 'cashhand-extensions' ),
					'param_name' => 'columns',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Products Wide Layout Columns', 'cashhand-extensions' ),
					'param_name' => 'product_columns_wide',
					'holder' => 'div',
					'description' => esc_html__( 'Option only works if Wide Cashhand Layout enabled.', 'cashhand-extensions' ),
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'show_carousel_nav',
					'heading' => esc_html__( 'Show Carousel Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'show_top_text',
					'heading' => esc_html__( 'Show Top Text', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'show_categories',
					'heading' => esc_html__( 'Show Categories', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Limit', 'cashhand-extensions' ),
					'param_name' => 'limit',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name' => 'cat_limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'cat_has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'cat_orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'cat_order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_include',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_slugs',
					'holder' => 'div'
				),

			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products Carousel
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Products Carousel', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_carousel',
			'description' => esc_html__( 'Add products carousel to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of products to display', 'cashhand-extensions' ),
					'param_name' => 'limit',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'show_custom_nav',
					'heading' => esc_html__( 'Show Custom Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Products Wide Layout Columns', 'cashhand-extensions' ),
					'param_name'	=> 'product_columns_wide',
					'description'	=> esc_html__('Option only works if Wide Cashhand Layout enabled.', 'cashhand-extensions'),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items', 'cashhand-extensions' ),
					'param_name' => 'items',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(0 - 479)', 'cashhand-extensions' ),
					'param_name' => 'items_0',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(480 - 767)', 'cashhand-extensions' ),
					'param_name' => 'items_480',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(768 - 991)', 'cashhand-extensions' ),
					'param_name' => 'items_768',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(992 - 1199)', 'cashhand-extensions' ),
					'param_name' => 'items_992',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(1200 - 1429)', 'cashhand-extensions' ),
					'param_name' => 'items_1200',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_nav',
					'heading' => esc_html__( 'Carousel: Show Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Nav Next Text', 'cashhand-extensions' ),
					'param_name' => 'nav_next',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Nav Prev Text', 'cashhand-extensions' ),
					'param_name' => 'nav_prev',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Margin', 'cashhand-extensions' ),
					'param_name' => 'margin',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products Carousel 1
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Products Carousel 1', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_carousel_1',
			'description' => esc_html__( 'Add products carousel to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Action Text', 'cashhand-extensions' ),
					'param_name' => 'button_text',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Action Link', 'cashhand-extensions' ),
					'param_name' => 'button_link',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of products to display', 'cashhand-extensions' ),
					'param_name' => 'limit',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items', 'cashhand-extensions' ),
					'param_name' => 'items',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Margin', 'cashhand-extensions' ),
					'param_name' => 'margin',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_nav',
					'heading' => esc_html__( 'Carousel: Show Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div',
					'value'			=>  'trending-products-carousel'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products Carousel With Timer
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Products Carousel With Timer', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_carousel_with_timer',
			'description' => esc_html__( 'Add products carousel with timer to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'header_timer',
					'heading' => esc_html__( 'Show Header Timer', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'param_name'	=> 'timer_title',
					'heading'		=> esc_html__('Timer Title', 'cashhand-extensions' ),
					'holder' => 'div'
				),

				array(
					'type'			=> 'textfield',
					'param_name'	=> 'timer_value',
					'heading'		=> esc_html__('Timer Value', 'cashhand-extensions' ),
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Action Text', 'cashhand-extensions' ),
					'param_name' => 'button_text',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Action Link', 'cashhand-extensions' ),
					'param_name' => 'button_link',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of products to display', 'cashhand-extensions' ),
					'param_name' => 'limit',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items', 'cashhand-extensions' ),
					'param_name' => 'items',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Margin', 'cashhand-extensions' ),
					'param_name' => 'margin',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_nav',
					'heading' => esc_html__( 'Carousel: Show Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div',
					'value'			=>  'products-carousel-with-timer'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Brands Carousel
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Brands Carousel', 'cashhand-extensions' ),
			'base' => 'cashhand_brands_carousel',
			'description' => esc_html__( 'Add brands carousel to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon' => 'vc-el-element-icon',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Brands to display', 'cashhand-extensions' ),
					'param_name' => 'limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Brands does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'include',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_loop',
					'heading' => esc_html__( 'Carousel: Loop', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product List Categories
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Product List Categories', 'cashhand-extensions' ),
			'base' => 'cashhand_product_list_categories',
			'description' => esc_html__( 'Add product categories to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon' => 'vc-el-element-icon',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name' => 'limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'name\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'ASC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'slugs',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'include',
					'holder' => 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product Categories Block
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Product Categories Block', 'cashhand-extensions' ),
			'base'			=> 'cashhand_product_categories_block',
			'description'	=> esc_html__( 'Add product categories to your page.', 'cashhand-extensions' ),
			'class'			=> '',
			'controls'		=> 'full',
			'icon'			=> 'vc-el-element-icon',
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name'	=> 'title',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter Columns', 'cashhand-extensions' ),
					'param_name'	=> 'columns',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name'	=> 'limit',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'checkbox',
					'param_name'	=> 'has_no_products',
					'heading'		=> esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description'	=> esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value'			=> array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name'	=> 'orderby',
					'description'	=> esc_html__( ' Sort retrieved posts by parameter. Defaults to \'name\'. One or more options can be passed', 'cashhand-extensions' ),
					'value'			=> 'date',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name'	=> 'order',
					'description'	=> esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'ASC\'.', 'cashhand-extensions' ),
					'value'			=> 'DESC',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name'	=> 'slugs',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name'	=> 'include',
					'holder'		=> 'div'
				),
				array(
					'type' 			=> 'checkbox',
					'param_name' 	=> 'enable_full_width',
					'heading' 		=> esc_html__( 'Enable Fullwidth', 'cashhand-extensions' ),
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Category Icons Carousel
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Product Category Icons Carousel Block', 'cashhand-extensions' ),
			'base'			=> 'cashhand_home_category_icon_carousel',
			'description'	=> esc_html__( 'Add product category icons carousel to your page.', 'cashhand-extensions' ),
			'class'			=> '',
			'controls'		=> 'full',
			'icon'			=> 'vc-el-element-icon',
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'		=> array(
				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Style', 'cashhand-extensions' ),
					'value' 		=> array(
						esc_html__( 'Style v1', 'cashhand-extensions' ) => 'v1',
						esc_html__( 'Style v2', 'cashhand-extensions' ) => 'v2',
					),
					'param_name'	=> 'style',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name'	=> 'limit',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'checkbox',
					'param_name'	=> 'has_no_products',
					'heading'		=> esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description'	=> esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value'			=> array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name'	=> 'orderby',
					'description'	=> esc_html__( ' Sort retrieved posts by parameter. Defaults to \'name\'. One or more options can be passed', 'cashhand-extensions' ),
					'value'			=> 'date',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name'	=> 'order',
					'description'	=> esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'ASC\'.', 'cashhand-extensions' ),
					'value'			=> 'DESC',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name'	=> 'slugs',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name'	=> 'include',
					'holder'		=> 'div'
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items', 'cashhand-extensions' ),
					'param_name' => 'items',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(0 - 479)', 'cashhand-extensions' ),
					'param_name' => 'items_0',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(480 - 767)', 'cashhand-extensions' ),
					'param_name' => 'items_480',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(768 - 991)', 'cashhand-extensions' ),
					'param_name' => 'items_768',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(992 - 1199)', 'cashhand-extensions' ),
					'param_name' => 'items_992',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product Carousel Tabs with Deal
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'				=> esc_html__( 'Product Carousel Tabs with Deal', 'cashhand-extensions' ),
			'base'  			=> 'cashhand_products_tabs_carousel_with_deal',
			'description'		=> esc_html__( 'Add Product Carousel Tabs with deal to your page.', 'cashhand-extensions' ),
			'category'			=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'icon'				=> 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'params' 			=> array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Title', 'cashhand-extensions' ),
					'param_name' => 'section_title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Action Text', 'cashhand-extensions' ),
					'param_name' => 'button_text',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Action Link', 'cashhand-extensions' ),
					'param_name' => 'button_link',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Deal title', 'cashhand-extensions' ),
					'param_name' => 'deal_title',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'deal_show_savings',
					'heading' => esc_html__( 'Show Savings Details', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Show Savings', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Savings in', 'cashhand-extensions' ),
					'value' 		=> array(
						esc_html__( 'Amount', 'cashhand-extensions' ) => 'amount',
						esc_html__( 'Percentage', 'cashhand-extensions' ) => 'percentage'
					),
					'param_name'	=> 'deal_savings_in',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Savings Text', 'cashhand-extensions' ),
					'param_name' => 'deal_savings_text',
					'holder' => 'div'
				),

				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'value' 		=> array(
						esc_html__( 'Recent', 'cashhand-extensions' ) => 'recent',
						esc_html__( 'Random', 'cashhand-extensions' ) => 'random',
						esc_html__( 'Specific', 'cashhand-extensions' ) => 'specific'
					),
					'param_name'	=> 'deal_product_choice',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Product ID', 'cashhand-extensions' ),
					'param_name' => 'deal_product_id',
					'holder' => 'div'
				),
				
				array(
					'type' 		 => 'param_group',
					'value' 	 => '',
					'heading'	 => esc_html__('Tabs', 'cashhand-extensions' ),
					'param_name' => 'tabs',
					'params' 	 => array(
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Title', 'cashhand-extensions' ),
							'param_name'	=> 'title',
							'description'	=> esc_html__('Enter title.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'dropdown',
							'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
							'param_name'	=> 'shortcode_tag',
							'value'			=> array(
								esc_html__( 'Select', 'cashhand-extensions' )				=> '',
								esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
								esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
								esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
								esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
								esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
								esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
								esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
								esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
							),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Order By', 'cashhand-extensions' ),
							'param_name'	=> 'orderby',
							'description'	=> esc_html__('Enter orderby.', 'cashhand-extensions'),
							'value'			=> 'date'
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Order', 'cashhand-extensions' ),
							'param_name'	=> 'order',
							'description'	=> esc_html__('Enter order.', 'cashhand-extensions'),
							'value'			=> 'desc'
						),
						
						array(
							'type'			=> 'dropdown',
							'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
							'param_name'	=> 'products_choice',
							'value'			=> array(
								esc_html__( 'Select', 'cashhand-extensions' )		=> '',
								esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
								esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
							),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
							'param_name'	=> 'product_id',
							'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
							'param_name'	=> 'category',
							'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
							'param_name'	=> 'cat_operator',
							'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
							'value'			=> 'IN',
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
							'param_name'	=> 'attribute',
							'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
							'param_name'	=> 'terms',
							'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
							'param_name'	=> 'terms_operator',
							'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
							'value'			=> 'IN',
						),
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
					'param_name'	=> 'per_page',
					'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
					'value' => 20,
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Rows', 'cashhand-extensions' ),
					'param_name' => 'rows',
					'holder' => 'div',
					'value' => 2,
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Columns', 'cashhand-extensions' ),
					'param_name' => 'columns',
					'holder' => 'div',
					'value' => 5,
				),
				
				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
			),
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product Categories List
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Product Categories List', 'cashhand-extensions' ),
			'base'			=> 'cashhand_product_categories_list',
			'description'	=> esc_html__( 'Add product categories to your page.', 'cashhand-extensions' ),
			'class'			=> '',
			'controls'		=> 'full',
			'icon'			=> 'vc-el-element-icon',
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter Columns', 'cashhand-extensions' ),
					'param_name'	=> 'columns',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name'	=> 'limit',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'checkbox',
					'param_name'	=> 'has_no_products',
					'heading'		=> esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description'	=> esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value'			=> array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name'	=> 'orderby',
					'description'	=> esc_html__( ' Sort retrieved posts by parameter. Defaults to \'name\'. One or more options can be passed', 'cashhand-extensions' ),
					'value'			=> 'date',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name'	=> 'order',
					'description'	=> esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'ASC\'.', 'cashhand-extensions' ),
					'value'			=> 'DESC',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name'	=> 'slugs',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name'	=> 'include',
					'holder'		=> 'div'
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Deals Products Block
	#-----------------------------------------------------------------
	
	vc_map(
		array(
			'name'			=> esc_html__( 'Deals Products Block', 'cashhand-extensions' ),
			'base'			=> 'cashhand_deal_products_block',
			'description'	=> esc_html__( 'Add product categories to your page.', 'cashhand-extensions' ),
			'class'			=> '',
			'controls'		=> 'full',
			'icon'			=> 'vc-el-element-icon',
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'		=> array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
					'param_name'	=> 'per_page',
					'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
					'value'			=> '6',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Columns', 'cashhand-extensions' ),
					'param_name'	=> 'columns',
					'description'	=> esc_html__('Enter the number of columns to display.', 'cashhand-extensions'),
					'value'			=> '3',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Action Text', 'cashhand-extensions' ),
					'param_name'	=> 'action_text',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Action Link', 'cashhand-extensions' ),
					'param_name'	=> 'action_link',
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products One Two Block
	#-----------------------------------------------------------------
	
	vc_map(
		array(
			'name'			=> esc_html__( 'Products 1-2 Block', 'cashhand-extensions' ),
			'base'			=> 'cashhand_products_1_2_block',
			'description'	=> esc_html__( 'Add product categories to your page.', 'cashhand-extensions' ),
			'class'			=> '',
			'controls'		=> 'full',
			'icon'			=> 'vc-el-element-icon',
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'		=> array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Action Text', 'cashhand-extensions' ),
					'param_name'	=> 'action_text',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Action Link', 'cashhand-extensions' ),
					'param_name'	=> 'action_link',
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product Catgories List With Header Image 
	#-----------------------------------------------------------------
	
	vc_map(
		array(
			'name'			=> esc_html__( 'Product Catgories List With Header Image ', 'cashhand-extensions' ),
			'base'			=> 'cashhand_product_categories_list_with_header',
			'description'	=> esc_html__( 'Add product categories to your page.', 'cashhand-extensions' ),
			'class'			=> '',
			'controls'		=> 'full',
			'icon'			=> 'vc-el-element-icon',
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'		=> array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Subtitle', 'cashhand-extensions' ),
					'param_name' => 'sub_title',
					'holder' => 'div'
				),

				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Background Image', 'cashhand-extensions' ),
					'param_name' 	=> 'bg_image',
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'enable_header',
					'heading' => esc_html__( 'Enable Header', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show header block.', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter Columns', 'cashhand-extensions' ),
					'param_name'	=> 'columns',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name'	=> 'limit',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'checkbox',
					'param_name'	=> 'has_no_products',
					'heading'		=> esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description'	=> esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value'			=> array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name'	=> 'orderby',
					'description'	=> esc_html__( ' Sort retrieved posts by parameter. Defaults to \'name\'. One or more options can be passed', 'cashhand-extensions' ),
					'value'			=> 'date',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name'	=> 'order',
					'description'	=> esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'ASC\'.', 'cashhand-extensions' ),
					'value'			=> 'DESC',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name'	=> 'slugs',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name'	=> 'include',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Header Version', 'cashhand-extensions' ),
					'param_name'	=> 'type',
					'value'			=> array(
						esc_html__( 'Type 1', 'cashhand-extensions' )		=> 'v1' ,
						esc_html__( 'Type 2', 'cashhand-extensions' )		=> 'v2' 	,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product 2-1-2 Grid
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Product 2-1-2 Grid', 'cashhand-extensions' ),
			'base' => 'cashhand_products_2_1_2',
			'description' => esc_html__( 'Add products to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon' => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name' => 'cat_limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'cat_has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'cat_orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'cat_order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_include',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_slugs',
					'holder' => 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product 6-1 Grid
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Product 6-1 Grid', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_6_1',
			'description' => esc_html__( 'Add products to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon' => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name' => 'cat_limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'cat_has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'cat_orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'cat_order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_include',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_slugs',
					'holder' => 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products 6-1 with categories
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Products 6-1 with Categories', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_6_1_with_categories',
			'description' => esc_html__( 'Add products 6-1 with vertical categories to your page.', 'cashhand-extensions' ),
			'class'	=> '',
			'controls' => 'full',
			'icon' => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Featured Product Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'featured_shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
					),
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Featured Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'featured_products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
					'description'	=> esc_html__('Only for Products Shortcode.', 'cashhand-extensions'),
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Featured Product ID', 'cashhand-extensions'),
					'param_name'	=> 'featured_product_id',
					'description'	=> esc_html__('Enter ID/SKU. Only for Products Shortcode.', 'cashhand-extensions'),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter categories title', 'cashhand-extensions' ),
					'param_name' => 'categories_title',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'enable_categories',
					'heading' => esc_html__( 'Enable Header Categories', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories list on header block.', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name' => 'cat_limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'cat_has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'cat_orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'cat_order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_include',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_slugs',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Vertical Categories to display', 'cashhand-extensions' ),
					'param_name' => 'vcat_limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'vcat_has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'vcat_orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'vcat_order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'vcat_include',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'vcat_slugs',
					'holder' => 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products with categories and image
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Products with Categories and Image', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_with_category_image',
			'description' => esc_html__( 'Add products with vertical categories and image to your page.', 'cashhand-extensions' ),
			'class'	=> '',
			'controls' => 'full',
			'icon' => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
					'param_name'	=> 'per_page',
					'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Columns', 'cashhand-extensions' ),
					'param_name'	=> 'columns',
					'description'	=> esc_html__('Enter the number of columns to display.', 'cashhand-extensions'),
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Products Wide Layout Columns', 'cashhand-extensions' ),
					'param_name'	=> 'columns_wide',
					'description'	=> esc_html__('Option only works if Wide Cashhand Layout enabled.', 'cashhand-extensions'),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter categories title', 'cashhand-extensions' ),
					'param_name' => 'categories_title',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'enable_categories',
					'heading' => esc_html__( 'Enable Header Categories', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories list on header block.', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name' => 'cat_limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'cat_has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'cat_orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'cat_order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_include',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_slugs',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Vertical Categories to display', 'cashhand-extensions' ),
					'param_name' => 'vcat_limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'vcat_has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'vcat_orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'vcat_order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'vcat_include',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'vcat_slugs',
					'holder' => 'div'
				),

				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Image', 'cashhand-extensions' ),
					'param_name' 	=> 'image',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Image Action Link', 'cashhand-extensions' ),
					'param_name' => 'img_action_link',
					'holder' => 'div'
				)
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Onsale Product
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Onsale Product', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_product_onsale',
			'description' => esc_html__( 'Add onsale product to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon' => 'vc-el-element-icon',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),
				array(
					'type' => 'checkbox',
					'param_name' => 'show_savings',
					'heading' => esc_html__( 'Show Savings Details', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Show Savings', 'cashhand-extensions' ) => 'true'
					)
				),
				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Savings in', 'cashhand-extensions' ),
					'value' 		=> array(
						esc_html__( 'Amount', 'cashhand-extensions' ) => 'amount',
						esc_html__( 'Percentage', 'cashhand-extensions' ) => 'percentage'
					),
					'param_name'	=> 'savings_in',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Savings Text', 'cashhand-extensions' ),
					'param_name' => 'savings_text',
					'holder' => 'div'
				),
				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'value' 		=> array(
						esc_html__( 'Recent', 'cashhand-extensions' ) => 'recent',
						esc_html__( 'Random', 'cashhand-extensions' ) => 'random',
						esc_html__( 'Specific', 'cashhand-extensions' ) => 'specific'
					),
					'param_name'	=> 'product_choice',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Product ID', 'cashhand-extensions' ),
					'param_name' => 'product_id',
					'holder' => 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Onsale Product Carousel
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Onsale Products Carousel', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_onsale_carousel',
			'description' => esc_html__( 'Add onsale products carousel to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'show_savings',
					'heading' => esc_html__( 'Show Savings Details', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Show Savings', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Savings in', 'cashhand-extensions' ),
					'value' 		=> array(
						esc_html__( 'Amount', 'cashhand-extensions' ) => 'amount',
						esc_html__( 'Percentage', 'cashhand-extensions' ) => 'percentage'
					),
					'param_name'	=> 'savings_in',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Savings Text', 'cashhand-extensions' ),
					'param_name' => 'savings_text',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Products to display', 'cashhand-extensions' ),
					'param_name' => 'limit',
					'holder' => 'div'
				),

				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'value' 		=> array(
						esc_html__( 'Recent', 'cashhand-extensions' ) => 'recent',
						esc_html__( 'Random', 'cashhand-extensions' ) => 'random',
						esc_html__( 'Specific', 'cashhand-extensions' ) => 'specific'
					),
					'param_name'	=> 'product_choice',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Product ID', 'cashhand-extensions' ),
					'param_name' => 'product_id',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'show_custom_nav',
					'heading' => esc_html__( 'Show Custom Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'show_progress',
					'heading' => esc_html__( 'Show Progress', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'show_timer',
					'heading' => esc_html__( 'Show Timer', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'show_cart_btn',
					'heading' => esc_html__( 'Show Cart Button', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Nav Next Text', 'cashhand-extensions' ),
					'param_name' => 'nav_next',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Nav Prev Text', 'cashhand-extensions' ),
					'param_name' => 'nav_prev',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Margin', 'cashhand-extensions' ),
					'param_name' => 'margin',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products Carousel with Category Tabs
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'				=> esc_html__( 'Cashhand Products Carousel with Category Tabs', 'cashhand-extensions' ),
			'base'				=> 'cashhand_vc_products_carousel_with_category_tabs',
			'description'		=> esc_html__( 'Add products 6-1 with vertical categories to your page.', 'cashhand-extensions' ),
			'class'				=> '',
			'controls'			=> 'full',
			'icon'				=> 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category'			=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'			=> array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
					'param_name'	=> 'per_page',
					'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
					'value'			=> '6',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'enable_categories',
					'heading' => esc_html__( 'Enable Header Categories', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories list on header block.', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter categories title', 'cashhand-extensions' ),
					'param_name' => 'categories_title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name' => 'cat_limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'cat_has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'cat_orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'cat_order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_include',
					'description' => esc_html__( 'Enter IDs of Categories to display', 'cashhand-extensions' ),
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_slugs',
					'description' => esc_html__( 'Enter slug of Categories to display', 'cashhand-extensions' ),
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items', 'cashhand-extensions' ),
					'param_name' => 'items',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Margin', 'cashhand-extensions' ),
					'param_name' => 'margin',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_nav',
					'heading' => esc_html__( 'Carousel: Show Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products List Block
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'				=> esc_html__( 'Cashhand Products List Block', 'cashhand-extensions' ),
			'base'				=> 'cashhand_vc_products_list',
			'description'		=> esc_html__( 'Add Products list to your page.', 'cashhand-extensions' ),
			'class'				=> '',
			'controls'			=> 'full',
			'icon'				=> 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category'			=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'			=> array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__('Type', 'cashhand-extensions' ),
					'param_name'	=> 'type',
					'value'			=> array(
						esc_html__( 'v1',   'cashhand-extensions')	=> 'v1',
						esc_html__( 'v2', 	'cashhand-extensions')	=> 'v2'
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Action Text', 'cashhand-extensions' ),
					'param_name' => 'action_text',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Action Link', 'cashhand-extensions' ),
					'param_name' => 'action_link',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
					'param_name'	=> 'per_page',
					'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
					'value'			=> '6',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'enable_categories',
					'heading' => esc_html__( 'Enable Header Categories', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories list on header block.', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter categories title', 'cashhand-extensions' ),
					'param_name' => 'categories_title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name' => 'cat_limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'cat_has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'cat_orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'cat_order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_include',
					'description' => esc_html__( 'Enter IDs of Categories to display', 'cashhand-extensions' ),
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_slugs',
					'description' => esc_html__( 'Enter slug of Categories to display', 'cashhand-extensions' ),
					'holder' => 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product Carousel Tabs 1 Element
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'				=> esc_html__( 'Product Carousel Tabs 1', 'cashhand-extensions' ),
			'base'  			=> 'cashhand_products_tabs_carousel_1',
			'description'		=> esc_html__( 'Add Product Carousel Tabs to your page.', 'cashhand-extensions' ),
			'category'			=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'icon'				=> 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'params' 			=> array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'section_title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Action Text', 'cashhand-extensions' ),
					'param_name' => 'button_text',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Action Link', 'cashhand-extensions' ),
					'param_name' => 'button_link',
					'holder' => 'div'
				),
				
				array(
					'type' 		 => 'param_group',
					'value' 	 => '',
					'heading'	 => esc_html__('Tabs', 'cashhand-extensions' ),
					'param_name' => 'tabs',
					'params' 	 => array(
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Title', 'cashhand-extensions' ),
							'param_name'	=> 'title',
							'description'	=> esc_html__('Enter title.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'dropdown',
							'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
							'param_name'	=> 'shortcode_tag',
							'value'			=> array(
								esc_html__( 'Select', 'cashhand-extensions' )				=> '',
								esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
								esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
								esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
								esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
								esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
								esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
								esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
								esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
							),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
							'param_name'	=> 'per_page',
							'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Order By', 'cashhand-extensions' ),
							'param_name'	=> 'orderby',
							'description'	=> esc_html__('Enter orderby.', 'cashhand-extensions'),
							'value'			=> 'date'
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Order', 'cashhand-extensions' ),
							'param_name'	=> 'order',
							'description'	=> esc_html__('Enter order.', 'cashhand-extensions'),
							'value'			=> 'desc'
						),
						
						array(
							'type'			=> 'dropdown',
							'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
							'param_name'	=> 'products_choice',
							'value'			=> array(
								esc_html__( 'Select', 'cashhand-extensions' )		=> '',
								esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
								esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
							),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
							'param_name'	=> 'product_id',
							'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
							'param_name'	=> 'category',
							'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
							'param_name'	=> 'cat_operator',
							'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
							'value'			=> 'IN',
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
							'param_name'	=> 'attribute',
							'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
							'param_name'	=> 'terms',
							'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
							'param_name'	=> 'terms_operator',
							'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
							'value'			=> 'IN',
						),
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items', 'cashhand-extensions' ),
					'param_name' => 'items',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_nav',
					'heading' => esc_html__( 'Carousel: Show Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
				
				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
			),
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Deal Products Carousel
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Deal Products Carousel', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_deal_products_carousel',
			'description' => esc_html__( 'Add deal products carousel to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter deal header title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'header_timer',
					'heading' => esc_html__( 'Show Header Timer', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'param_name'	=> 'timer_value',
					'heading'		=> esc_html__('Timer Value', 'cashhand-extensions' ),
					'holder' => 'div'
				),

				array(
					'type'			=> 'textfield',
					'param_name'	=> 'timer_title',
					'heading'		=> esc_html__('Timer Title', 'cashhand-extensions' ),
					'holder' => 'div'
				),

				array(
					'type'			=> 'textfield',
					'param_name'	=> 'deal_percentage',
					'heading'		=> esc_html__('Deal Percentage value', 'cashhand-extensions' ),
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of products to display', 'cashhand-extensions' ),
					'param_name' => 'limit',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items', 'cashhand-extensions' ),
					'param_name' => 'items',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_nav',
					'heading' => esc_html__( 'Carousel: Show Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Nav Next Text', 'cashhand-extensions' ),
					'param_name' => 'nav_next',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Nav Prev Text', 'cashhand-extensions' ),
					'param_name' => 'nav_prev',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Margin', 'cashhand-extensions' ),
					'param_name' => 'margin',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Deals and Products Tabs
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Deal and Products Tabs', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_deal_and_product_tab',
			'description' => esc_html__( 'Add deal and products tabs to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon' => 'vc-el-element-icon',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'deal_title',
					'holder' => 'div'
				),
				array(
					'type' => 'checkbox',
					'param_name' => 'deal_show_savings',
					'heading' => esc_html__( 'Show Savings Details', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Show Savings', 'cashhand-extensions' ) => 'true'
					)
				),
				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Savings in', 'cashhand-extensions' ),
					'value' 		=> array(
						esc_html__( 'Amount', 'cashhand-extensions' ) => 'amount',
						esc_html__( 'Percentage', 'cashhand-extensions' ) => 'percentage'
					),
					'param_name'	=> 'deal_savings_in',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Savings Text', 'cashhand-extensions' ),
					'param_name' => 'deal_savings_text',
					'holder' => 'div'
				),
				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'value' 		=> array(
						esc_html__( 'Recent', 'cashhand-extensions' ) => 'recent',
						esc_html__( 'Random', 'cashhand-extensions' ) => 'random',
						esc_html__( 'Specific', 'cashhand-extensions' ) => 'specific'
					),
					'param_name'	=> 'deal_product_choice',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Product ID', 'cashhand-extensions' ),
					'param_name' => 'deal_product_id',
					'holder' => 'div'
				),
				array(
					'type' 		 => 'param_group',
					'value' 	 => '',
					'heading'	 => esc_html__('Tabs', 'cashhand-extensions' ),
					'param_name' => 'tabs',
					'params' 	 => array(
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Title', 'cashhand-extensions' ),
							'param_name'	=> 'title',
							'description'	=> esc_html__('Enter title.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'dropdown',
							'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
							'param_name'	=> 'shortcode_tag',
							'value'			=> array(
								esc_html__( 'Select', 'cashhand-extensions' )				=> '',
								esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
								esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
								esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
								esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
								esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
								esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
								esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
								esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
							),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
							'param_name'	=> 'product_limit',
							'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
						),

						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Columns', 'cashhand-extensions' ),
							'param_name'	=> 'columns',
							'description'	=> esc_html__('Enter the number of columns to display.', 'cashhand-extensions'),
						),

						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Wide Layout Limit', 'cashhand-extensions' ),
							'param_name'	=> 'product_limit_wide',
							'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
						),
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Order By', 'cashhand-extensions' ),
							'param_name'	=> 'orderby',
							'description'	=> esc_html__('Enter orderby.', 'cashhand-extensions'),
							'value'			=> 'date'
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Order', 'cashhand-extensions' ),
							'param_name'	=> 'order',
							'description'	=> esc_html__('Enter order.', 'cashhand-extensions'),
							'value'			=> 'desc'
						),
						
						array(
							'type'			=> 'dropdown',
							'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
							'param_name'	=> 'products_choice',
							'value'			=> array(
								esc_html__( 'Select', 'cashhand-extensions' )		=> '',
								esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
								esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
							),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
							'param_name'	=> 'product_id',
							'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
							'param_name'	=> 'category',
							'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
							'param_name'	=> 'cat_operator',
							'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
							'value'			=> 'IN',
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
							'param_name'	=> 'attribute',
							'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
							'param_name'	=> 'terms',
							'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
						),
						
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
							'param_name'	=> 'terms_operator',
							'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
							'value'			=> 'IN',
						),
					)
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Tab Products Wide Layout Columns', 'cashhand-extensions' ),
					'param_name'	=> 'product_columns_wide',
					'description'	=> esc_html__('Enter the number of tap products wide layout columns to display.', 'cashhand-extensions'),
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand List Categories Menus
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'				=> esc_html__( 'List Categories Menus', 'cashhand-extensions' ),
			'base'				=> 'cashhand_product_categories_menu_list',
			'description'		=> esc_html__( 'Add List Categories Menus to your page.', 'cashhand-extensions' ),
			'category'			=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'icon'				=> 'vc-el-element-icon',
			'params' 		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Section Title', 'cashhand-extensions' ),
					'param_name'	=> 'section_title',
				),
				array(
					'type' 		 => 'param_group',
					'value' 	 => '',
					'heading'	 => esc_html__('List Categories Menus', 'cashhand-extensions' ),
					'param_name' => 'list_categories',
					'params' 	 => array(
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Title', 'cashhand-extensions' ),
							'param_name'	=> 'title',
						),

						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Category Slug', 'cashhand-extensions' ),
							'param_name'	=> 'slugs',
							'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
							'param_name' => 'orderby',
							'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
							'value' => 'date',
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
							'param_name' => 'order',
							'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
							'value' => 'DESC',
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Number of categories to display', 'cashhand-extensions' ),
							'param_name' => 'limit',
							'holder' => 'div'
						),

						array(
							'type' => 'checkbox',
							'param_name' => 'cat_has_no_products',
							'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
							'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
							'value' => array(
								esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
							)
						),
					)
				),

				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Action Text', 'cashhand-extensions' ),
					'param_name'	=> 'action_text',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Action Link', 'cashhand-extensions' ),
					'param_name'	=> 'action_link',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div'
				)
			),
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Nav Menu
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Nav Menu', 'cashhand-extensions' ),
			'base' => 'cashhand_nav_menu',
			'description' => esc_html__( 'Add a navigation menu to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'cashhand-extensions' ),
					'param_name' 	=> 'title',
					'description' 	=> esc_html__( 'Enter the title of menu.', 'cashhand-extensions' ),
					'holder' 		=> 'div'
				),
				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Menu', 'cashhand-extensions' ),
					'value' 		=> $nav_menus_option,
					'param_name'	=> 'menu',
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Recently Viewed Products
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'				=> esc_html__( 'Recently Viewed Products Block', 'cashhand-extensions' ),
			'base'				=> 'cashhand_recent_viewed_products',
			'description'		=> esc_html__( 'Add Recently Viewed Products Block to your page.', 'cashhand-extensions' ),
			'category'			=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'icon'				=> 'vc-el-element-icon',
			'params' 		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Section Title', 'cashhand-extensions' ),
					'param_name'	=> 'section_title',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
					'param_name'	=> 'per_page',
					'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Columns', 'cashhand-extensions' ),
					'param_name'	=> 'columns',
					'description'	=> esc_html__('Enter the number of columns to display.', 'cashhand-extensions'),
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Columns Wide', 'cashhand-extensions' ),
					'param_name'	=> 'columns_wide',
					'description'	=> esc_html__('Enter the number of columns wide to display.', 'cashhand-extensions'),
				),
			),
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products Carousel Category with Image
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Products Carousel Category with Image', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_carousel_category_with_image',
			'description' => esc_html__( 'Add products carousel category with image to your page.', 'cashhand-extensions' ),
			'class'	=> '',
			'controls' => 'full',
			'icon' => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'enable_categories',
					'heading' => esc_html__( 'Enable Header Categories', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories list on header block.', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter categories title', 'cashhand-extensions' ),
					'param_name' => 'categories_title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name' => 'cat_limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'cat_has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'cat_orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'cat_order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_include',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_slugs',
					'holder' => 'div'
				),

				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Image', 'cashhand-extensions' ),
					'param_name' 	=> 'image',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Image Action Link', 'cashhand-extensions' ),
					'param_name' => 'img_action_link',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'description',
					'heading' => esc_html__( 'Enable Description', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Description on the products.', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items', 'cashhand-extensions' ),
					'param_name' => 'items',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(0 - 479)', 'cashhand-extensions' ),
					'param_name' => 'items_0',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(480 - 767)', 'cashhand-extensions' ),
					'param_name' => 'items_480',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(768 - 991)', 'cashhand-extensions' ),
					'param_name' => 'items_768',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items(992 - 1199)', 'cashhand-extensions' ),
					'param_name' => 'items_992',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				)
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Products Category with Image
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Products Category with Image', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_category_with_image',
			'description' => esc_html__( 'Add products category with image to your page.', 'cashhand-extensions' ),
			'class'	=> '',
			'controls' => 'full',
			'icon' => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'enable_categories',
					'heading' => esc_html__( 'Enable Header Categories', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories list on header block.', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter categories title', 'cashhand-extensions' ),
					'param_name' => 'categories_title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name' => 'cat_limit',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'cat_has_no_products',
					'heading' => esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'cat_orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'cat_order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_include',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name' => 'cat_slugs',
					'holder' => 'div'
				),

				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Image', 'cashhand-extensions' ),
					'param_name' 	=> 'image',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Image Action Link', 'cashhand-extensions' ),
					'param_name' => 'img_action_link',
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
					'param_name'	=> 'per_page',
					'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Columns', 'cashhand-extensions' ),
					'param_name'	=> 'columns',
					'description'	=> esc_html__('Enter the number of columns to display.', 'cashhand-extensions'),
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Columns Wide', 'cashhand-extensions' ),
					'param_name'	=> 'columns_wide',
					'description'	=> esc_html__('Option only works if Wide Cashhand Layout enabled.', 'cashhand-extensions'),
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div',
					'value'			=>  ''
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Recent Viewed Products Carousel
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Recent Viewed Products Carousel', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_recent_viewed_products_carousel',
			'description' => esc_html__( 'Add recent viewed products carousel to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Carousel: Items', 'cashhand-extensions' ),
					'param_name' => 'items',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_dots',
					'heading' => esc_html__( 'Carousel: Show Dots', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div',
					'value'			=>  'recently-viewed-products-carousel'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Two Row Products
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Two Row Products', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_two_row_products',
			'description' => esc_html__( 'Add two row products to your page.', 'cashhand-extensions' ),
			'class'	=> '',
			'controls' => 'full',
			'icon' => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Action Text', 'cashhand-extensions' ),
					'param_name'	=> 'action_text',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Action Link', 'cashhand-extensions' ),
					'param_name'	=> 'action_link',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Limit', 'cashhand-extensions' ),
					'param_name'	=> 'per_page',
					'description'	=> esc_html__('Enter the number of products to display.', 'cashhand-extensions'),
					'value'			=> 12,
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Columns', 'cashhand-extensions' ),
					'param_name'	=> 'columns',
					'description'	=> esc_html__('Enter the number of columns to display.', 'cashhand-extensions'),
					'value'			=> 6,
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Columns Wide', 'cashhand-extensions' ),
					'param_name'	=> 'columns_wide',
					'description'	=> esc_html__('Option only works if Wide Cashhand Layout enabled.', 'cashhand-extensions'),
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				)
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Vertical Nav Menu
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Vertical Nav Menu', 'cashhand-extensions' ),
			'base' => 'cashhand_vertical_nav_menu',
			'description' => esc_html__( 'Add a verical navigation menu to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'cashhand-extensions' ),
					'param_name' 	=> 'title',
					'description' 	=> esc_html__( 'Enter the title of menu.', 'cashhand-extensions' ),
					'holder' 		=> 'div'
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__('Action Text', 'cashhand-extensions' ),
					'param_name'	=> 'action_text',
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Action Link', 'cashhand-extensions' ),
					'param_name'	=> 'action_link',
				),
				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Menu', 'cashhand-extensions' ),
					'value' 		=> $nav_menus_option,
					'param_name'	=> 'menu',
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Team Member
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Team Member', 'cashhand-extensions' ),
			'base' => 'cashhand_team_member',
			'description' => esc_html__( 'Add a team member profile to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					 'type' 		=> 'textfield',
					 'heading' 		=> esc_html__( 'Full Name', 'cashhand-extensions' ),
					 'param_name' 	=> 'name',
					 'description' 	=> esc_html__( 'Enter team member full name', 'cashhand-extensions' ),
					 'holder' 		=> 'div'
				),
				array(
					 'type' 		=> 'textfield',
					 'heading' 		=> esc_html__( 'Designation', 'cashhand-extensions' ),
					 'param_name' 	=> 'designation',
					 'description' 	=> esc_html__( 'Enter designation of team member', 'cashhand-extensions'),
				),
				array(
					'type' 			=> 'attach_image',
					'heading' 		=> esc_html__( 'Profile Pic', 'cashhand-extensions' ),
					'param_name' 	=> 'profile_pic',
				),
				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Display Style', 'cashhand-extensions' ),
					'value' 		=> array(
						esc_html__( 'Square', 'cashhand-extensions' ) => 'square',
						esc_html__( 'Circle', 'cashhand-extensions' ) => 'circle'
					),
					'param_name'	=> 'display_style',
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> esc_html__( 'Link', 'cashhand-extensions' ),
					'param_name' 	=> 'link',
					'description' 	=> esc_html__( 'Add link to the team member. Leave blank if there aren\'t any', 'cashhand-extensions' )
				),
				array(
					'type' 			=> 'textfield',
					'class' 		=> '',
					'heading' 		=> esc_html__( 'Extra Class', 'cashhand-extensions' ),
					'param_name' 	=> 'el_class',
					'description' 	=> esc_html__( 'Add your extra classes here.', 'cashhand-extensions' )
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Terms
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'        => esc_html__( 'Cashhand Terms', 'cashhand-extensions' ),
			'base'        => 'cashhand_terms',
			'description' => esc_html__( 'Adds a shortcode for get_terms. Used to get terms including categories, product categories, etc.', 'cashhand-extensions' ),
			'class'		  => '',
			'controls'    => 'full',
			'icon'    	  => 'vc-el-element-icon',
			'category'    => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'      => array(
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Taxonomy', 'cashhand-extensions' ),
					'param_name'   => 'taxonomy',
					'description'  => esc_html__( 'Taxonomy name, or comma-separated taxonomies, to which results should be limited.', 'cashhand-extensions' ),
					'value'        => 'category',
					'holder'       => 'div'
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Order By', 'cashhand-extensions' ),
					'param_name'   => 'orderby',
					'description'  => esc_html__( 'Field(s) to order terms by. Accepts term fields (\'name\', \'slug\', \'term_group\', \'term_id\', \'id\', \'description\'). Defaults to \'name\'.', 'cashhand-extensions' ),
					'value'        => 'name'
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name'   => 'order',
					'description'  => esc_html__( 'Whether to order terms in ascending or descending order. Accepts \'ASC\' (ascending) or \'DESC\' (descending). Default \'ASC\'.', 'cashhand-extensions' ),
					'value'        => 'ASC'
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Hide Empty ?', 'cashhand-extensions' ),
					'param_name'   => 'hide_empty',
					'description'  => esc_html__( 'Whether to hide terms not assigned to any posts. Accepts 1 or 0. Default 0.', 'cashhand-extensions' ),
					'value'        => '0'
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Include IDs', 'cashhand-extensions' ),
					'param_name'   => 'include',
					'description'  => esc_html__( 'Comma-separated string of term ids to include.', 'cashhand-extensions' ),
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Exclude IDs', 'cashhand-extensions' ),
					'param_name'   => 'exclude',
					'description'  => esc_html__( 'Comma-separated string of term ids to exclude. If Include is non-empty, Exclude is ignored.', 'cashhand-extensions' ),
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Number', 'cashhand-extensions' ),
					'param_name'   => 'number',
					'description'  => esc_html__( 'Maximum number of terms to return. Accepts 0 (all) or any positive number. Default 0 (all).', 'cashhand-extensions' ),
					'value'        => '0',
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Offset', 'cashhand-extensions' ),
					'param_name'   => 'offset',
					'description'  => esc_html__( 'The number by which to offset the terms query.', 'cashhand-extensions' ),
					'value'        => '0',
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Name', 'cashhand-extensions' ),
					'param_name'   => 'name',
					'description'  => esc_html__( 'Name or comma-separated string of names to return term(s) for.', 'cashhand-extensions' ),
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Slug', 'cashhand-extensions' ),
					'param_name'   => 'slug',
					'description'  => esc_html__( 'Slug or comma-separated string of slugs to return term(s) for.', 'cashhand-extensions' ),
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Hierarchical', 'cashhand-extensions' ),
					'param_name'   => 'hierarchical',
					'description'  => esc_html__( 'Whether to include terms that have non-empty descendants. Accepts 1 (true) or 0 (false). Default 1 (true)', 'cashhand-extensions' ),
					'value'        => '1',
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Child Of', 'cashhand-extensions' ),
					'param_name'   => 'child_of',
					'description'  => esc_html__( 'Term ID to retrieve child terms of. If multiple taxonomies are passed, child_of is ignored. Default 0.', 'cashhand-extensions' ),
					'value'        => '0',
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Include "Child Of" term ?', 'cashhand-extensions' ),
					'param_name'   => 'include_parent',
					'description'  => esc_html__( 'Include "Child Of" term in the terms list. Accepts 1 (yes) or 0 (no). Default 1.', 'cashhand-extensions' ),
					'value'        => '1',
				),
				array(
					'type'         => 'textfield',
					'heading'      => esc_html__( 'Parent', 'cashhand-extensions' ),
					'param_name'   => 'parent',
					'description'  => esc_html__( 'Parent term ID to retrieve direct-child terms of.', 'cashhand-extensions' ),
					'value'        => '',
				)
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Mobile Deals product Block
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Mobile Deals Product', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_mobile_deal_products_with_featured',
			'description' => esc_html__( 'Add deal product with featured to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'admin_enqueue_js'	=> Cashhand_Extensions_URL . 'assets/js/vc-admin.js',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter header title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'header_timer',
					'heading' => esc_html__( 'Show Header Timer', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'param_name'	=> 'timer_value',
					'heading'		=> esc_html__('Timer Value', 'cashhand-extensions' ),
					'holder' => 'div'
				),

				array(
					'type'			=> 'textfield',
					'param_name'	=> 'timer_title',
					'heading'		=> esc_html__('Timer Title', 'cashhand-extensions' ),
					'holder' => 'div'
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Shortcode', 'cashhand-extensions' ),
					'param_name'	=> 'shortcode_tag',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )				=> '',
						esc_html__( 'Featured Products', 'cashhand-extensions' )		=> 'featured_products' ,
						esc_html__( 'On Sale Products', 'cashhand-extensions' )		=> 'sale_products' 	,
						esc_html__( 'Top Rated Products', 'cashhand-extensions' )	=> 'top_rated_products' ,
						esc_html__( 'Recent Products', 'cashhand-extensions' )		=> 'recent_products' 	,
						esc_html__( 'Best Selling Products', 'cashhand-extensions' )	=> 'best_selling_products',
						esc_html__( 'Products', 'cashhand-extensions' )				=> 'products' ,
						esc_html__( 'Product Category', 'cashhand-extensions' )		=> 'product_category' ,
						esc_html__( 'Product Attribute', 'cashhand-extensions' )		=> 'product_attribute' ,
					),
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of products to display', 'cashhand-extensions' ),
					'param_name' => 'limit',
					'holder' => 'div'
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name' => 'orderby',
					'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
					'value' => 'date',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name' => 'order',
					'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
					'value' => 'DESC',
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'param_name'	=> 'products_choice',
					'value'			=> array(
						esc_html__( 'Select', 'cashhand-extensions' )		=> '',
						esc_html__( 'IDs', 'cashhand-extensions' )		=> 'ids' ,
						esc_html__( 'SKUs', 'cashhand-extensions' )		=> 'skus' ,
					),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__('Product IDs or SKUs', 'cashhand-extensions'),
					'param_name'	=> 'product_id',
					'description'	=> esc_html__('Enter IDs/SKUs spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category', 'cashhand-extensions' ),
					'param_name'	=> 'category',
					'description'	=> esc_html__('Enter slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Category Operator', 'cashhand-extensions' ),
					'param_name'	=> 'cat_operator',
					'description'	=> esc_html__('Operator to compare categories. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Attribute', 'cashhand-extensions' ),
					'param_name'	=> 'attribute',
					'description'	=> esc_html__('Enter single attribute slug.', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms', 'cashhand-extensions' ),
					'param_name'	=> 'terms',
					'description'	=> esc_html__('Enter term slug spearate by comma(,).', 'cashhand-extensions'),
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Terms Operator', 'cashhand-extensions' ),
					'param_name'	=> 'terms_operator',
					'description'	=> esc_html__('Operator to compare terms. Possible values are \'IN\', \'NOT IN\', \'AND\'.', 'cashhand-extensions'),
					'value'			=> 'IN',
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product Category Tags
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Product Category Tags', 'cashhand-extensions' ),
			'base'			=> 'cashhand_product_category_tags',
			'description'	=> esc_html__( 'Add product categories to your page.', 'cashhand-extensions' ),
			'class'			=> '',
			'controls'		=> 'full',
			'icon'			=> 'vc-el-element-icon',
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter section title', 'cashhand-extensions' ),
					'param_name'	=> 'title',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Number of Categories to display', 'cashhand-extensions' ),
					'param_name'	=> 'limit',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'checkbox',
					'param_name'	=> 'has_no_products',
					'heading'		=> esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description'	=> esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value'			=> array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name'	=> 'orderby',
					'description'	=> esc_html__( ' Sort retrieved posts by parameter. Defaults to \'name\'. One or more options can be passed', 'cashhand-extensions' ),
					'value'			=> 'date',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name'	=> 'order',
					'description'	=> esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'ASC\'.', 'cashhand-extensions' ),
					'value'			=> 'DESC',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'param_name'	=> 'slugs',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'param_name'	=> 'include',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product Categories 1-6
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Product Categories 1-6', 'cashhand-extensions' ),
			'base'			=> 'cashhand_products_categories_1_6',
			'description'	=> esc_html__( 'Add product categories to your page.', 'cashhand-extensions' ),
			'class'			=> '',
			'controls'		=> 'full',
			'icon'			=> 'vc-el-element-icon',
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'		=> array(
				array(
					'type'			=> 'checkbox',
					'param_name'	=> 'has_no_products',
					'heading'		=> esc_html__( 'Have no products', 'cashhand-extensions' ),
					'description'	=> esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
					'value'			=> array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order by', 'cashhand-extensions' ),
					'param_name'	=> 'orderby',
					'description'	=> esc_html__( ' Sort retrieved posts by parameter. Defaults to \'name\'. One or more options can be passed', 'cashhand-extensions' ),
					'value'			=> 'date',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Order', 'cashhand-extensions' ),
					'param_name'	=> 'order',
					'description'	=> esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'ASC\'.', 'cashhand-extensions' ),
					'value'			=> 'DESC',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include slug\'s', 'cashhand-extensions' ),
					'description'	=> esc_html__( 'Enter slug spearate by comma(,). Maximum of 7.', 'cashhand-extensions' ),
					'param_name'	=> 'slugs',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Include ID\'s', 'cashhand-extensions' ),
					'description'	=> esc_html__( 'Enter ids spearate by comma(,). Maximum of 7.', 'cashhand-extensions' ),
					'param_name'	=> 'include',
					'holder'		=> 'div'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div'
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Onsale Product Carousel 2
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name' => esc_html__( 'Cashhand Onsale Products Carousel 2', 'cashhand-extensions' ),
			'base' => 'cashhand_vc_products_onsale_carousel_2',
			'description' => esc_html__( 'Add onsale products carousel to your page.', 'cashhand-extensions' ),
			'class'		=> '',
			'controls' => 'full',
			'icon'  => 'vc-el-element-icon',
			'category' => esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of Products to display', 'cashhand-extensions' ),
					'param_name' => 'limit',
					'holder' => 'div'
				),

				array(
					'type' 			=> 'dropdown',
					'heading'		=> esc_html__( 'Product Choice', 'cashhand-extensions' ),
					'value' 		=> array(
						esc_html__( 'Recent', 'cashhand-extensions' ) => 'recent',
						esc_html__( 'Random', 'cashhand-extensions' ) => 'random',
						esc_html__( 'Specific', 'cashhand-extensions' ) => 'specific'
					),
					'param_name'	=> 'product_choice',
				),

				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Product ID', 'cashhand-extensions' ),
					'param_name' => 'product_id',
					'holder' => 'div'
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'show_timer',
					'heading' => esc_html__( 'Show Timer', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_nav',
					'heading' => esc_html__( 'Show Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),
			)
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Banners 1-6 Block
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Banners 1-6 Block', 'cashhand-extensions' ),
			'base'			=> 'cashhand_home_banner_1_6_block',
			'description'	=> esc_html__( 'Add banners to your page.', 'cashhand-extensions' ),
			'class'			=> '',
			'controls'		=> 'full',
			'icon'			=> 'vc-el-element-icon',
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'		=> $banners_1_6_params,
		)
	);

	#-----------------------------------------------------------------
	# Cashhand Product Categories With Banner Carousel
	#-----------------------------------------------------------------
	vc_map(
		array(
			'name'			=> esc_html__( 'Product Categories With Banner Carousel', 'cashhand-extensions' ),
			'base'			=> 'cashhand_product_categories_with_banner_carousel',
			'class'			=> '',
			'controls'		=> 'full',
			'icon'			=> 'vc-el-element-icon',
			'category'		=> esc_html__( 'Cashhand Elements', 'cashhand-extensions' ),
			'params'		=> array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Enter Section Title', 'cashhand-extensions' ),
					'param_name' => 'title',
					'holder' => 'div'
				),

				array(
					'type' 		 => 'param_group',
					'value' 	 => '',
					'heading'	 => esc_html__('Carousel Elements', 'cashhand-extensions' ),
					'param_name' => 'elements',
					'params' 	 => array(
						array(
							'type' => 'checkbox',
							'param_name' => 'enable_category_1',
							'heading' => esc_html__( 'Enable Categories 1', 'cashhand-extensions' ),
							'value' => array(
								esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
							)
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Categories List 1: limit', 'cashhand-extensions' ),
							'param_name' => 'cat_1_limit',
							'holder' => 'div'
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Categories List 1: Child limit', 'cashhand-extensions' ),
							'param_name' => 'cat_1_child_limit',
							'holder' => 'div'
						),

						array(
							'type' => 'checkbox',
							'param_name' => 'cat_1_has_no_products',
							'heading' => esc_html__( 'Categories List 1: Have no products', 'cashhand-extensions' ),
							'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
							'value' => array(
								esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
							)
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Categories List 1: Order by', 'cashhand-extensions' ),
							'param_name' => 'cat_1_orderby',
							'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
							'value' => 'date',
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Categories List 1: Order', 'cashhand-extensions' ),
							'param_name' => 'cat_1_order',
							'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
							'value' => 'DESC',
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Categories List 1: Include ID\'s', 'cashhand-extensions' ),
							'param_name' => 'cat_1_include',
							'holder' => 'div'
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Categories List 1: Include slug\'s', 'cashhand-extensions' ),
							'param_name' => 'cat_1_slugs',
							'holder' => 'div'
						),

						array(
							'type' => 'checkbox',
							'param_name' => 'enable_category_2',
							'heading' => esc_html__( 'Enable Categories 2', 'cashhand-extensions' ),
							'value' => array(
								esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
							)
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Categories List 2: limit', 'cashhand-extensions' ),
							'param_name' => 'cat_2_limit',
							'holder' => 'div'
						),

						array(
							'type' => 'checkbox',
							'param_name' => 'cat_2_has_no_products',
							'heading' => esc_html__( 'Categories List 2: Have no products', 'cashhand-extensions' ),
							'description' => esc_html__( 'Show Categories does not have products', 'cashhand-extensions' ),
							'value' => array(
								esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
							)
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Categories List 2: Order by', 'cashhand-extensions' ),
							'param_name' => 'cat_2_orderby',
							'description' => esc_html__( ' Sort retrieved posts by parameter. Defaults to \'date\'. One or more options can be passed', 'cashhand-extensions' ),
							'value' => 'date',
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Categories List 2: Order', 'cashhand-extensions' ),
							'param_name' => 'cat_2_order',
							'description' => esc_html__( 'Designates the ascending or descending order of the \'orderby\' parameter. Defaults to \'DESC\'.', 'cashhand-extensions' ),
							'value' => 'DESC',
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Categories List 2: Include ID\'s', 'cashhand-extensions' ),
							'param_name' => 'cat_2_include',
							'holder' => 'div'
						),

						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Categories List 2: Include slug\'s', 'cashhand-extensions' ),
							'param_name' => 'cat_2_slugs',
							'holder' => 'div'
						),

						array(
							'type' => 'checkbox',
							'param_name' => 'enable_banner',
							'heading' => esc_html__( 'Enable Banner ?', 'cashhand-extensions' ),
							'value' => array(
								esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
							)
						),

						array(
							'type' 			=> 'attach_image',
							'heading' 		=> esc_html__( 'Banner Image', 'cashhand-extensions' ),
							'param_name' 	=> 'image',
						),

						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Banner Action Link', 'cashhand-extensions' ),
							'param_name'	=> 'img_action_link',
						),
					),
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_nav',
					'heading' => esc_html__( 'Carousel: Show Navigation', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_touchdrag',
					'heading' => esc_html__( 'Carousel: Enable Touch Drag', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type' => 'checkbox',
					'param_name' => 'is_autoplay',
					'heading' => esc_html__( 'Carousel: Autoplay', 'cashhand-extensions' ),
					'value' => array(
						esc_html__( 'Allow', 'cashhand-extensions' ) => 'true'
					)
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Enter class name', 'cashhand-extensions' ),
					'param_name'	=> 'el_class',
					'holder'		=> 'div'
				),
			),
		)
	);

endif;
