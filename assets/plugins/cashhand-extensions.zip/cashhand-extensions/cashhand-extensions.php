<?php
/**
 * Plugin Name:    	Cashhand Marketplace Extensions
 * Plugin URI:     	https://dacosta.ml/cashhand/
 * Description:    	This selection of extensions compliment our lean and mean theme for WooCommerce, Cashhand. Please note: they don’t work with any WordPress theme, just Cashhand.
 * Author:         	MadrasThemes
 * Author URL:     	https://dacosta.ml/
 * Version:        	1.0.0
 * Text Domain: 	cashhand-extensions
 * Domain Path: 	/languages
 * WC tested up to: 5.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'Cashhand_Extensions' ) ) {
	/**
	 * Main Cashhand_Extensions Class
	 *
	 * @class Cashhand_Extensions
	 * @version	1.0.0
	 * @since 1.0.0
	 * @package	Kudos
	 * @author Ibrahim
	 */
	final class Cashhand_Extensions {
		/**
		 * Cashhand_Extensions The single instance of Cashhand_Extensions.
		 * @var 	object
		 * @access  private
		 * @since 	1.0.0
		 */
		private static $_instance = null;

		/**
		 * The token.
		 * @var     string
		 * @access  public
		 * @since   1.0.0
		 */
		public $token;

		/**
		 * The version number.
		 * @var     string
		 * @access  public
		 * @since   1.0.0
		 */
		public $version;

		/**
		 * Constructor function.
		 * @access  public
		 * @since   1.0.0
		 * @return  void
		 */
		public function __construct () {
			
			$this->token 	= 'cashhand-extensions';
			$this->version 	= '0.0.1';
			
			add_action( 'plugins_loaded', array( $this, 'setup_constants' ),		10 );
			add_action( 'plugins_loaded', array( $this, 'includes' ),				20 );
			add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ),	30 );
		}

		/**
		 * Main Cashhand_Extensions Instance
		 *
		 * Ensures only one instance of Cashhand_Extensions is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @see Cashhand_Extensions()
		 * @return Main Kudos instance
		 */
		public static function instance () {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		/**
		 * Setup plugin constants
		 *
		 * @access public
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_constants() {

			// Plugin Folder Path
			if ( ! defined( 'Cashhand_Extensions_DIR' ) ) {
				define( 'Cashhand_Extensions_DIR', plugin_dir_path( __FILE__ ) );
			}

			// Plugin Folder URL
			if ( ! defined( 'Cashhand_Extensions_URL' ) ) {
				define( 'Cashhand_Extensions_URL', plugin_dir_url( __FILE__ ) );
			}

			// Plugin Root File
			if ( ! defined( 'Cashhand_Extensions_FILE' ) ) {
				define( 'Cashhand_Extensions_FILE', __FILE__ );
			}

			// Modules File
			if ( ! defined( 'CASHHAND_MODULES_DIR' ) ) {
				define( 'CASHHAND_MODULES_DIR', Cashhand_Extensions_DIR . '/modules' );
			}
		}

		/**
		 * Include required files
		 *
		 * @access public
		 * @since  1.0.0
		 * @return void
		 */
		public function includes() {

			#-----------------------------------------------------------------
			# Plugin Functions
			#-----------------------------------------------------------------

			require Cashhand_Extensions_DIR . '/includes/functions.php';

			if( function_exists( 'is_mas_static_content_activated' ) && is_mas_static_content_activated() ) {
				require CASHHAND_MODULES_DIR . '/mas-static-content-migrator/index.php';
			}

			#-----------------------------------------------------------------
			# Post Formats
			#-----------------------------------------------------------------
			require CASHHAND_MODULES_DIR . '/post-formats/post-formats.php';

			if( ! ( function_exists( 'is_mas_static_content_activated' ) && is_mas_static_content_activated() && function_exists( 'cashhand_is_mas_static_content_migrated' ) && cashhand_is_mas_static_content_migrated() ) ) {
				#-----------------------------------------------------------------
				# Static Block Post Type
				#-----------------------------------------------------------------
				require_once CASHHAND_MODULES_DIR . '/post-types/static-block.php';
			}

			#-----------------------------------------------------------------
			# Visual Composer Extensions
			#-----------------------------------------------------------------
			require_once CASHHAND_MODULES_DIR . '/js_composer/js_composer.php';

			#-----------------------------------------------------------------
			# Theme Shortcodes
			#-----------------------------------------------------------------
			require_once CASHHAND_MODULES_DIR . '/theme-shortcodes/theme-shortcodes.php';

			#-----------------------------------------------------------------
			# Elementor Extensions
			#-----------------------------------------------------------------
			require_once CASHHAND_MODULES_DIR . '/elementor/elementor.php';

			#-----------------------------------------------------------------
			# Page Templates
			#-----------------------------------------------------------------
			// require CASHHAND_MODULES_DIR . '/page-templates/class-cashhand-page-templates.php';
		}

		/**
		 * Load the localisation file.
		 * @access  public
		 * @since   1.0.0
		 * @return  void
		 */
		public function load_plugin_textdomain() {
			load_plugin_textdomain( 'cashhand-extensions', false, dirname( plugin_basename( Cashhand_Extensions_FILE ) ) . '/languages/' );
		}

		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone () {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'cashhand-extensions' ), '1.0.0' );
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup () {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'cashhand-extensions' ), '1.0.0' );
		}
	}
}

/**
 * Returns the main instance of Cashhand_Extensions to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return object Cashhand_Extensions
 */
function Cashhand_Extensions() {
	return Cashhand_Extensions::instance();
}

/**
 * Initialise the plugin
 */
Cashhand_Extensions();